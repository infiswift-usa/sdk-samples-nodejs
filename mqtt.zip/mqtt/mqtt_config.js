module.exports = {
    mqtt: {
        "server": "poc-shimla-broker.infiswift.tech",
        "port": "1883",
        "username": "slozymoh",
        "password": "344ecbc1-7c02-4c91-a61a-0d15b07e45a8",
        "clientId": "753a26b375a7469a91ff32eb9b23f284",
        "topicprefix": "/infiswift.com/stream/version/1/id/"
    }
}